import React from "react";
import "./NavBar.css"


// Depending on the current path, this component sets the "active" class on the appropriate navigation link item
function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <a className="navbar-brand" href="/">
        LinkedUp
      </a>
      <ul>
      <li className="submenu">  <a> About us </a> 
          <ul> 
            <li> <a> mouse </a></li>
            <li> <a> keyboard </a></li>
            <li className="submenu"> <a> camera </a>
              <ul className="infoBar">
              <li> <div> data </div> </li>
              </ul>
            </li>
          </ul> 
      </li>
      <li>  <a> Services </a> </li>
      <li> <a> Contact Us </a> </li>
      <li> <a> Pricing </a>   </li>

     </ul>
    </nav>
  );
}

export default Navbar;
