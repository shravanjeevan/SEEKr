import React from 'react';
import Layout from '../layouts/index';
import img from '../images/job-match2.jpg';

const AboutPage = () => {
  return (
    <Layout>
      <article className="entry">
        <div className="container">
          <div className="entry-inner">
            <div className="entry-content">
              <div className="container-sm">
                <header className="entry-header">
                  <h1 className="entry-title">About</h1>
                </header>

                <div className="entry-body">
                  <p>
                    Holly is a free HTML/CSS landing page designed and developed by
                    @pacovitiello and @DavidePacilio!
                </p>
                  <p>
                    Holly is suitable for all kind of startups, it's easily
                    customizable, and it's downloadable for personal and commercial
                    use.
                </p>
                  <hr />
                  <p>Live demo: <a href="https://demo.cruip.com/holly/">https://demo.cruip.com/holly/</a></p>
                  <hr />
                  <p>This template is distributed under the MIT License.</p>
                </div>
              </div>
            </div>
              <div className="img">
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <img src={img} alt="" />
              </div>
          </div>
        </div>
      </article>
    </Layout>
  );
};

export default AboutPage;
